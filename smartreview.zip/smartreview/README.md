# SmartReview: A Peer-to-Peer AI Study App with Adaptive Testing for CvSU Imus

## A. Get your OpenAI API key
1. Go to https://platform.openai.com and click **Sign up** (or **Log in**).
2. Verify your email (and phone number if asked).
3. Open **Settings → Billing** (https://platform.openai.com/settings/organization/billing).
4. Click **Add payment details** and add credits (the minimum is about $5). The API is pay-as-you-go and is separate from ChatGPT Plus. Without credits you get a "quota" error.
5. Open **API keys** (https://platform.openai.com/api-keys) and click **Create new secret key**.
6. Name it `smartreview`, click **Create**, and **copy the key right away**. It starts with `sk-` and is shown only once.
7. Paste it into `.env`: `OPENAI_API_KEY=sk-...`
8. Never share the key or upload it to GitHub.

Tip: set a monthly limit in Billing → Limits. `gpt-4o-mini` is cheap, and one quiz costs a fraction of a peso.

## B. Set up MySQL
1. Install MySQL (or XAMPP and start MySQL).
2. Run the schema: `mysql -u root -p < schema.sql` (or paste `schema.sql` into phpMyAdmin / MySQL Workbench and run it).
3. In `.env`, set `DB_USER` and `DB_PASSWORD`. XAMPP default: user `root`, empty password.

## C. Run in VS Code
1. Install Node.js 18+ from https://nodejs.org
2. Open this folder in VS Code, then open the terminal (Ctrl+`).
3. `npm install`
4. `npm start`
5. Open http://localhost:3000, create an account, and upload a reviewer.

## Files
- `server.js` – API, login, file parsing, OpenAI calls, adaptive logic
- `schema.sql` – MySQL tables
- `public/` – HTML, CSS, JS (dark UI)
