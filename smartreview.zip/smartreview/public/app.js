const $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let me = null;

async function api(url, opt = {}) {
  const isForm = opt.body instanceof FormData;
  const r = await fetch(url, isForm ? opt : { headers: { 'Content-Type': 'application/json' }, ...opt, body: opt.body ? JSON.stringify(opt.body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Something went wrong.');
  return d;
}
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2800); }
async function busy(btn, label, fn) {
  const old = btn.textContent; btn.disabled = true; btn.textContent = label;
  try { await fn(); } catch (e) { toast(e.message); } finally { btn.disabled = false; btn.textContent = old; }
}

function header(active) {
  $('#top').innerHTML = `<span class="brand">SmartReview</span>` + (me ? `<nav>
    <button data-v="dash" class="${active === 'dash' ? 'on' : ''}">Progress</button>
    <button data-v="lib" class="${active === 'lib' ? 'on' : ''}">Reviewers</button>
    <button data-v="out">Log out (${esc(me.name)})</button></nav>` : '');
  $('#top').querySelectorAll('[data-v]').forEach(b => b.onclick = async () => {
    if (b.dataset.v === 'out') { await api('/api/logout', { method: 'POST' }); me = null; return authView(); }
    b.dataset.v === 'dash' ? dashView() : libView();
  });
}

/* ---------- Login / Register ---------- */
function authView(mode = 'login') {
  header();
  const reg = mode === 'register';
  app.innerHTML = `<div class="panel auth">
    <h1>${reg ? 'Create account' : 'Log in'}</h1>
    <p class="muted">Study smarter with AI quizzes built from your own reviewers. For CvSU Imus students.</p>
    <form id="f">
      ${reg ? '<label>Full name</label><input name="name" required>' : ''}
      <label>Email</label><input name="email" type="email" required>
      <label>Password</label><input name="password" type="password" minlength="6" required>
      <div class="err" id="err"></div>
      <div class="row"><button class="btn" type="submit">${reg ? 'Create account' : 'Log in'}</button>
      <button class="btn ghost" type="button" id="sw">${reg ? 'I have an account' : 'Create account'}</button></div>
    </form></div>`;
  $('#sw').onclick = () => authView(reg ? 'login' : 'register');
  $('#f').onsubmit = async e => {
    e.preventDefault();
    try {
      await api(reg ? '/api/register' : '/api/login', { method: 'POST', body: Object.fromEntries(new FormData(e.target)) });
      me = await api('/api/me'); dashView();
    } catch (err) { $('#err').textContent = err.message; }
  };
}

/* ---------- Progress dashboard ---------- */
async function dashView() {
  header('dash');
  const { topics, history } = await api('/api/stats');
  const pct = t => Math.round(t.correct / t.total * 100);
  const cls = p => p < 50 ? 'weak' : p < 75 ? 'mid' : '';
  app.innerHTML = `<h1>Your progress</h1>
  <div class="panel"><h2>Score per attempt</h2>${history.length ? `
    <div class="spark">${history.map(h => `<span title="${esc(h.title)}: ${h.score}/${h.total}" style="height:${Math.max(4, h.score / h.total * 100)}%"></span>`).join('')}</div>
    <p class="muted">Oldest to newest. Hover a bar for details.</p>` : '<p class="muted">No attempts yet. Upload a reviewer and take your first quiz.</p>'}</div>
  <div class="panel"><h2>Topic mastery</h2>${topics.length ? topics.map(t => { const p = pct(t); return `
    <div class="item"><div class="grow"><b>${esc(t.topic)}</b> <span class="muted">${t.correct}/${t.total} correct</span>
    <div class="bar"><i class="${cls(p)}" style="width:${p}%"></i></div></div><b>${p}%</b></div>`; }).join('') : '<p class="muted">Topic results show up after your first quiz.</p>'}</div>
  <div class="panel"><h2>Recent attempts</h2>${history.slice().reverse().map(h => `
    <div class="item"><div><b>${esc(h.title)}</b> <span class="tag">${h.type === 'remedial' ? 'weak-area' : 'baseline'}</span><br>
    <span class="muted">${new Date(h.created_at).toLocaleString()}</span></div><b>${h.score}/${h.total}</b></div>`).join('') || '<p class="muted">Nothing yet.</p>'}</div>`;
}

/* ---------- Reviewer library ---------- */
async function libView(scope = 'mine') {
  header('lib');
  const list = await api('/api/reviewers?scope=' + scope);
  app.innerHTML = `<h1>Reviewers</h1>
  <div class="panel"><h2>Upload a reviewer</h2>
    <form id="up"><label>Title (optional)</label><input name="title">
    <label>File (PDF, DOCX, or TXT with readable text)</label><input type="file" name="file" accept=".pdf,.docx,.txt" required>
    <label class="inline"><input type="checkbox" id="pub"> Share with other CvSU Imus students</label>
    <button class="btn" type="submit">Upload</button></form></div>
  <div class="tabs"><button class="btn ${scope === 'mine' ? '' : 'ghost'}" id="t1">My reviewers</button>
  <button class="btn ${scope === 'public' ? '' : 'ghost'}" id="t2">Shared by peers</button></div>
  <div class="panel">${list.length ? list.map(r => `
    <div class="item"><div class="grow"><b>${esc(r.title)}</b> ${r.is_public ? '<span class="tag">shared</span>' : ''}<br>
    <span class="muted">by ${esc(r.owner)} · ${r.chars.toLocaleString()} characters</span></div>
    <div class="row">
      <select data-n="${r.id}" style="width:auto"><option>5</option><option selected>10</option><option>15</option><option>20</option></select>
      <button class="btn" data-gen="${r.id}">Make quiz</button>
      <button class="btn ghost" data-rem="${r.id}">Weak-area quiz</button>
      ${r.is_mine ? `<button class="btn ghost" data-share="${r.id}" data-pub="${r.is_public}">${r.is_public ? 'Unshare' : 'Share'}</button>
      <button class="btn danger" data-del="${r.id}">Delete</button>` : ''}
    </div></div>`).join('') : `<p class="muted">${scope === 'mine' ? 'No reviewers yet. Upload one above.' : 'No shared reviewers yet.'}</p>`}</div>`;
  $('#t1').onclick = () => libView('mine'); $('#t2').onclick = () => libView('public');
  $('#up').onsubmit = e => { e.preventDefault(); const fd = new FormData(e.target); fd.set('is_public', $('#pub').checked);
    busy(e.target.querySelector('button'), 'Uploading…', async () => { await api('/api/reviewers', { method: 'POST', body: fd }); toast('Uploaded.'); libView('mine'); }); };
  app.querySelectorAll('[data-gen]').forEach(b => b.onclick = () => busy(b, 'Generating…', async () => {
    const n = app.querySelector(`[data-n="${b.dataset.gen}"]`).value;
    const r = await api(`/api/reviewers/${b.dataset.gen}/quiz`, { method: 'POST', body: { count: n } }); quizView(r.quiz_id); }));
  app.querySelectorAll('[data-rem]').forEach(b => b.onclick = () => busy(b, 'Generating…', async () => {
    const r = await api(`/api/reviewers/${b.dataset.rem}/remedial`, { method: 'POST' }); quizView(r.quiz_id); }));
  app.querySelectorAll('[data-share]').forEach(b => b.onclick = async () => {
    await api(`/api/reviewers/${b.dataset.share}/share`, { method: 'PATCH', body: { is_public: b.dataset.pub !== '1' } }); libView(scope); });
  app.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
    if (confirm('Delete this reviewer and its quizzes?')) { await api('/api/reviewers/' + b.dataset.del, { method: 'DELETE' }); libView(scope); } });
}

/* ---------- Take quiz ---------- */
async function quizView(id) {
  header('lib');
  const q = await api('/api/quizzes/' + id);
  app.innerHTML = `<h1>${esc(q.title)}</h1>
  ${q.summary ? `<div class="panel"><h3>Your blind spots</h3><p>${esc(q.summary)}</p></div>` : ''}
  <form id="qz" class="panel">${q.questions.map((x, i) => `
    <div class="q"><div class="topic">${esc(x.topic)}</div><b>${i + 1}. ${esc(x.question)}</b>
    ${x.choices.map((c, j) => `<label class="choice"><input type="radio" name="${x.id}" value="${j}"> <span>${esc(c)}</span></label>`).join('')}</div>`).join('')}
    <button class="btn" type="submit">Submit answers</button></form>`;
  $('#qz').onsubmit = e => { e.preventDefault();
    const answers = {}; new FormData(e.target).forEach((v, k) => answers[k] = Number(v));
    busy(e.target.querySelector('button'), 'Checking…', async () => resultView(await api(`/api/quizzes/${id}/submit`, { method: 'POST', body: { answers } }))); };
}

/* ---------- Results ---------- */
function resultView(r) {
  const wrong = r.results.filter(x => !x.is_correct);
  const topics = [...new Set(wrong.map(x => x.topic))];
  app.innerHTML = `<div class="panel"><div class="score">${r.score}/${r.total}</div>
    <p>${wrong.length ? `Review these topics: <b>${topics.map(esc).join(', ')}</b>` : 'Perfect score. Nothing to review.'}</p>
    <div class="row"><button class="btn" id="rem" ${wrong.length ? '' : 'disabled'}>Make weak-area quiz</button>
    <button class="btn ghost" id="lib">Back to reviewers</button><button class="btn ghost" id="dash">View progress</button></div></div>
  <div class="panel">${r.results.map((x, i) => `
    <div class="q"><div class="topic">${esc(x.topic)}</div><b>${i + 1}. ${esc(x.question)}</b>
    ${x.choices.map((c, j) => `<div class="choice ${j === x.correct ? 'right' : j === x.chosen ? 'wrong' : ''}">${esc(c)}</div>`).join('')}
    ${x.chosen === null ? '<p class="muted">Not answered.</p>' : ''}<p class="muted">${esc(x.explanation)}</p></div>`).join('')}</div>`;
  $('#lib').onclick = () => libView(); $('#dash').onclick = dashView;
  $('#rem').onclick = e => busy(e.target, 'Generating…', async () => {
    const d = await api(`/api/reviewers/${r.reviewer_id}/remedial`, { method: 'POST' }); quizView(d.quiz_id); });
}

(async () => { me = await api('/api/me').catch(() => null); me ? dashView() : authView(); })();
