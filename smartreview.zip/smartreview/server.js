require('dotenv').config();
const express = require('express');
const session = require('express-session');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const pdf = require('pdf-parse');
const mammoth = require('mammoth');
const path = require('path');
const OpenAI = require('openai');

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const db = mysql.createPool({
  host: process.env.DB_HOST, user: process.env.DB_USER,
  password: process.env.DB_PASSWORD, database: process.env.DB_NAME,
  waitForConnections: true
});
const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-secret', resave: false,
  saveUninitialized: false, cookie: { maxAge: 7 * 864e5 }
}));
app.use(express.static(path.join(__dirname, 'public')));

const needLogin = (req, res, next) => req.session.uid ? next() : res.status(401).json({ error: 'Please log in.' });
const wrap = fn => (req, res) => fn(req, res).catch(e => { console.error(e); res.status(500).json({ error: e.message || 'Server error' }); });

// ---------- Auth ----------
app.post('/api/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6)
    return res.status(400).json({ error: 'Fill all fields. Password needs 6+ characters.' });
  const [dup] = await db.query('SELECT id FROM users WHERE email=?', [email.toLowerCase()]);
  if (dup.length) return res.status(400).json({ error: 'Email is already registered.' });
  const hash = await bcrypt.hash(password, 10);
  const [r] = await db.query('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)', [name.trim(), email.toLowerCase(), hash]);
  req.session.uid = r.insertId;
  res.json({ id: r.insertId, name });
}));
app.post('/api/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await db.query('SELECT * FROM users WHERE email=?', [(email || '').toLowerCase()]);
  if (!rows.length || !(await bcrypt.compare(password || '', rows[0].password_hash)))
    return res.status(400).json({ error: 'Wrong email or password.' });
  req.session.uid = rows[0].id;
  res.json({ id: rows[0].id, name: rows[0].name });
}));
app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/me', wrap(async (req, res) => {
  if (!req.session.uid) return res.json(null);
  const [r] = await db.query('SELECT id,name,email FROM users WHERE id=?', [req.session.uid]);
  res.json(r[0] || null);
}));

// ---------- Reviewers (upload + peer sharing) ----------
async function extractText(file) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (ext === '.pdf') return (await pdf(file.buffer)).text;
  if (ext === '.docx') return (await mammoth.extractRawText({ buffer: file.buffer })).value;
  if (ext === '.txt') return file.buffer.toString('utf8');
  throw new Error('Only PDF, DOCX, and TXT files are supported.');
}
app.post('/api/reviewers', needLogin, upload.single('file'), wrap(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a file.' });
  const text = (await extractText(req.file)).replace(/\s+\n/g, '\n').trim();
  if (text.length < 200)
    return res.status(400).json({ error: 'Not enough readable text. Scanned images and handwritten notes are not supported.' });
  const title = (req.body.title || req.file.originalname).slice(0, 200);
  const [r] = await db.query('INSERT INTO reviewers(user_id,title,content,is_public) VALUES(?,?,?,?)',
    [req.session.uid, title, text, req.body.is_public === 'true' ? 1 : 0]);
  res.json({ id: r.insertId });
}));
app.get('/api/reviewers', needLogin, wrap(async (req, res) => {
  const mine = req.query.scope !== 'public';
  const [rows] = await db.query(
    `SELECT r.id,r.title,r.is_public,r.created_at,u.name AS owner,r.user_id=? AS is_mine,CHAR_LENGTH(r.content) AS chars
     FROM reviewers r JOIN users u ON u.id=r.user_id
     WHERE ${mine ? 'r.user_id=?' : 'r.is_public=1'} ORDER BY r.id DESC`, [req.session.uid, ...(mine ? [req.session.uid] : [])]);
  res.json(rows);
}));
app.patch('/api/reviewers/:id/share', needLogin, wrap(async (req, res) => {
  await db.query('UPDATE reviewers SET is_public=? WHERE id=? AND user_id=?', [req.body.is_public ? 1 : 0, req.params.id, req.session.uid]);
  res.json({ ok: true });
}));
app.delete('/api/reviewers/:id', needLogin, wrap(async (req, res) => {
  await db.query('DELETE FROM reviewers WHERE id=? AND user_id=?', [req.params.id, req.session.uid]);
  res.json({ ok: true });
}));
async function getReadable(id, uid) {
  const [r] = await db.query('SELECT * FROM reviewers WHERE id=? AND (user_id=? OR is_public=1)', [id, uid]);
  return r[0];
}

// ---------- AI generation ----------
const RULES = `You are a strict quiz generator for university students.
Rules:
- Use ONLY facts found in the reviewer text. Never invent or add outside facts.
- Output valid JSON only: {"title":string,"summary":string,"questions":[{"topic":string,"question":string,"choices":[string,string,string,string],"answer":0,"explanation":string}]}
- "topic" is a short label (1-4 words). Reuse the exact same label for related questions.
- Each question has exactly 4 choices and exactly one correct choice. "answer" is its index (0-3). Spread correct answers across positions.
- Questions must be clear, unambiguous, and different from each other.
- "explanation" is one short sentence based on the text.`;

async function askAI(userPrompt) {
  const r = await ai.chat.completions.create({
    model: MODEL, temperature: 0.3, response_format: { type: 'json_object' },
    messages: [{ role: 'system', content: RULES }, { role: 'user', content: userPrompt }]
  });
  return JSON.parse(r.choices[0].message.content);
}
async function saveQuiz(uid, rid, type, data, fallbackTitle) {
  const qs = (data.questions || []).filter(q => q.question && Array.isArray(q.choices) && q.choices.length === 4 && q.answer >= 0 && q.answer <= 3);
  if (!qs.length) throw new Error('AI returned no valid questions. Try again.');
  const [r] = await db.query('INSERT INTO quizzes(user_id,reviewer_id,title,type,summary) VALUES(?,?,?,?,?)',
    [uid, rid, (data.title || fallbackTitle).slice(0, 200), type, type === 'remedial' ? data.summary : null]);
  for (const q of qs)
    await db.query('INSERT INTO questions(quiz_id,topic,question,choices,answer_idx,explanation) VALUES(?,?,?,?,?,?)',
      [r.insertId, String(q.topic || 'General').slice(0, 100), q.question, JSON.stringify(q.choices), q.answer, q.explanation || '']);
  return r.insertId;
}
const clip = t => t.slice(0, 14000);

app.post('/api/reviewers/:id/quiz', needLogin, wrap(async (req, res) => {
  const rv = await getReadable(req.params.id, req.session.uid);
  if (!rv) return res.status(404).json({ error: 'Reviewer not found.' });
  const n = Math.min(Math.max(parseInt(req.body.count) || 10, 5), 20);
  const data = await askAI(`Create a baseline quiz of ${n} multiple-choice questions covering the whole reviewer.\n\nREVIEWER TEXT:\n${clip(rv.content)}`);
  res.json({ quiz_id: await saveQuiz(req.session.uid, rv.id, 'baseline', data, rv.title + ' Quiz') });
}));

// ---------- Adaptive remediation ----------
app.post('/api/reviewers/:id/remedial', needLogin, wrap(async (req, res) => {
  const rv = await getReadable(req.params.id, req.session.uid);
  if (!rv) return res.status(404).json({ error: 'Reviewer not found.' });
  const [weak] = await db.query(
    `SELECT an.topic, SUM(an.is_correct=0) AS wrong, COUNT(*) AS total
     FROM answers an JOIN attempts att ON att.id=an.attempt_id JOIN quizzes q ON q.id=att.quiz_id
     WHERE att.user_id=? AND q.reviewer_id=? GROUP BY an.topic HAVING wrong>0
     ORDER BY wrong/total DESC, wrong DESC LIMIT 4`, [req.session.uid, rv.id]);
  if (!weak.length) return res.status(400).json({ error: 'No weak areas yet. Take a quiz on this reviewer and miss a few first.' });
  const list = weak.map(w => `${w.topic} (${w.wrong}/${w.total} wrong)`).join('; ');
  const data = await askAI(`The student is weak in these topics: ${list}.
In "summary", write 2-3 plain sentences describing the student's blind spots and what to review.
Create 8 multiple-choice questions focused ONLY on these topics. Use the exact topic labels given.\n\nREVIEWER TEXT:\n${clip(rv.content)}`);
  res.json({ quiz_id: await saveQuiz(req.session.uid, rv.id, 'remedial', data, rv.title + ' Weak-Area Quiz') });
}));

// ---------- Quiz taking ----------
app.get('/api/quizzes/:id', needLogin, wrap(async (req, res) => {
  const [q] = await db.query('SELECT id,title,type,summary FROM quizzes WHERE id=? AND user_id=?', [req.params.id, req.session.uid]);
  if (!q.length) return res.status(404).json({ error: 'Quiz not found.' });
  const [qs] = await db.query('SELECT id,topic,question,choices FROM questions WHERE quiz_id=? ORDER BY id', [req.params.id]);
  res.json({ ...q[0], questions: qs });
}));
app.post('/api/quizzes/:id/submit', needLogin, wrap(async (req, res) => {
  const [q] = await db.query('SELECT id FROM quizzes WHERE id=? AND user_id=?', [req.params.id, req.session.uid]);
  if (!q.length) return res.status(404).json({ error: 'Quiz not found.' });
  const [qs] = await db.query('SELECT * FROM questions WHERE quiz_id=? ORDER BY id', [req.params.id]);
  const given = req.body.answers || {};
  const results = qs.map(x => {
    const chosen = given[x.id] === undefined || given[x.id] === null ? null : Number(given[x.id]);
    return { id: x.id, topic: x.topic, question: x.question, choices: x.choices, chosen, correct: x.answer_idx, is_correct: chosen === x.answer_idx, explanation: x.explanation };
  });
  const score = results.filter(r => r.is_correct).length;
  const [a] = await db.query('INSERT INTO attempts(user_id,quiz_id,score,total) VALUES(?,?,?,?)', [req.session.uid, req.params.id, score, qs.length]);
  for (const r of results)
    await db.query('INSERT INTO answers(attempt_id,question_id,topic,chosen_idx,is_correct) VALUES(?,?,?,?,?)', [a.insertId, r.id, r.topic, r.chosen, r.is_correct ? 1 : 0]);
  const [rid] = await db.query('SELECT reviewer_id FROM quizzes WHERE id=?', [req.params.id]);
  res.json({ score, total: qs.length, reviewer_id: rid[0].reviewer_id, results });
}));

// ---------- Progress ----------
app.get('/api/stats', needLogin, wrap(async (req, res) => {
  const [topics] = await db.query(
    `SELECT an.topic, SUM(an.is_correct) AS correct, COUNT(*) AS total
     FROM answers an JOIN attempts att ON att.id=an.attempt_id WHERE att.user_id=?
     GROUP BY an.topic ORDER BY SUM(an.is_correct)/COUNT(*) ASC`, [req.session.uid]);
  const [history] = await db.query(
    `SELECT att.id,att.score,att.total,att.created_at,q.title,q.type,q.reviewer_id
     FROM attempts att JOIN quizzes q ON q.id=att.quiz_id WHERE att.user_id=? ORDER BY att.id DESC LIMIT 15`, [req.session.uid]);
  res.json({ topics, history: history.reverse() });
}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`SmartReview running at http://localhost:${PORT}`));
